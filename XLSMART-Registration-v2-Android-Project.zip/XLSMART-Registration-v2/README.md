# XLSMART Registration v2 — Android helper prototype

## Included
- XL / AXIS / Smartfren brand selection and official registration links.
- Optional remembered NIK, encrypted locally with AES-GCM and Android Keystore. The app does not upload the NIK.
- Barcode scanning via Google Play services Code Scanner. Manual entry remains available.
- Unreg helper: opens the SMS app with `UNREG#<number>#` addressed to 4444; user reviews and sends manually.
- Temporary in-session list of numbers to help select one for unreg.

## Official workflows and limitations
- Registration and face verification are completed on official operator websites. This app does not automate or bypass biometric checks.
- The scanner reads barcode text. A SIM barcode may contain ICCID rather than the phone number; verify the scanned value manually.
- Unreg SMS format and availability can vary by operator/account. Confirm current operator instructions and wait for official success confirmation. Smartfren also documents `mysf.id/unreg`.
- The app does not know how many numbers are linked to an NIK and cannot query operator records.
- Use only the customer's own NIK with informed consent. NIK is sensitive; use the remember option only on a device you control and delete it when no longer needed.

## Build and install APK (requires a computer with Android Studio)
1. Download and extract this ZIP.
2. Install Android Studio from https://developer.android.com/studio
3. Open Android Studio > Open > select the extracted `XLSMART-Registration-v2` folder.
4. Install Android SDK Platform 35 if Android Studio asks. Allow Gradle Sync and internet access so it can download dependencies.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, click Locate. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to the Android phone, tap it, allow Install unknown apps for the file manager/browser if prompted, then install.
8. Open XLSMART Registration. Internet and compatible Google Play services are needed for barcode scanning and official portals.

This environment cannot compile the APK because Android SDK/Gradle are not installed here. This ZIP is the Android Studio source project, not an installable APK.
