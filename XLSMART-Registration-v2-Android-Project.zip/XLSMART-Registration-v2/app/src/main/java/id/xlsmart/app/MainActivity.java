package id.xlsmart.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.View;
import android.widget.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.KeyStore;
import java.util.ArrayList;

import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

public class MainActivity extends Activity {
 private final int navy=Color.rgb(16,42,86), blue=Color.rgb(28,77,145), orange=Color.rgb(245,166,35), ink=Color.rgb(30,41,59);
 private LinearLayout body;
 private EditText phone,ccid;
 private String brand="XL";
 private android.content.SharedPreferences prefs;
 private final ArrayList<String> sessionNumbers=new ArrayList<>();
 private static final String ALIAS="xlsmart_nik_aes_key";

 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(navy);getWindow().setNavigationBarColor(navy);prefs=getSharedPreferences("xlsmart_secure",MODE_PRIVATE);home();}
 private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
 private TextView txt(String s,int z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 private Button btn(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(14);b.setTypeface(null,Typeface.BOLD);b.setTextColor(primary?Color.WHITE:navy);b.setBackground(shape(primary?blue:Color.rgb(232,239,248),18));return b;}
 private EditText field(String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setHint(hint);e.setInputType(type);e.setPadding(22,12,22,12);e.setBackground(shape(Color.rgb(246,248,251),16));return e;}
 private void gap(){View v=new View(this);body.addView(v,new LinearLayout.LayoutParams(1,12));}
 private void label(String s){TextView t=txt(s,14,ink,true);t.setPadding(2,0,0,6);body.addView(t);}
 private void note(String s){TextView t=txt(s,12,Color.rgb(130,78,25),false);t.setPadding(13,13,13,13);t.setBackground(shape(Color.rgb(255,244,225),16));body.addView(t);}
 private void shell(String title,String sub){
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(245,247,251));
  LinearLayout h=new LinearLayout(this);h.setOrientation(1);h.setPadding(23,24,23,22);h.setBackground(shape(navy,0));
  h.addView(txt("XLSMART",23,Color.WHITE,true));h.addView(txt("REGISTRATION ASSISTANT • DEMO",10,orange,true));
  TextView t=txt(title,23,Color.WHITE,true);t.setPadding(0,18,0,4);h.addView(t);h.addView(txt(sub,12,Color.rgb(220,230,244),false));root.addView(h);
  ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(20,20,20,28);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
 }
 private void home(){
  shell("Pilih brand","Pilih operator untuk registrasi atau unreg.");
  brandCard("XL","https://registrasi.xl.co.id/");
  brandCard("AXIS","https://registrasi.axis.co.id/");
  brandCard("Smartfren","https://mysf.id/reg");
  gap();label("PINTASAN UNREG");
  Button u=btn("Unreg nomor (SMS resmi 4444)",true);body.addView(u);u.setOnClickListener(v->unregForm());
  gap();Button saved=btn("Atur NIK tersimpan",false);body.addView(saved);saved.setOnClickListener(v->nikScreen());
  gap();note("Demo pendamping. Registrasi biometrik dan pengiriman permintaan tetap dilakukan pada sistem resmi operator. Aplikasi tidak mengambil foto wajah atau mengirim data identitas.");
 }
 private void brandCard(String b,String url){
  LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(14,12,14,12);c.setBackground(shape(Color.WHITE,16));
  c.addView(txt(b,18,navy,true));Button choose=btn("Pilih "+b,true);c.addView(choose);choose.setOnClickListener(v->{brand=b;nikScreen();});body.addView(c);gap();
 }
 private void nikScreen(){
  shell("Identitas pelanggan",brand+" • NIK disimpan hanya jika kamu mengaktifkan opsi ingat.");
  label("NIK 16 digit");
  EditText n=field("Masukkan NIK pelanggan",android.text.InputType.TYPE_CLASS_NUMBER);
  String old=loadNik(); if(old!=null)n.setText(old);body.addView(n);gap();
  CheckBox remember=new CheckBox(this);remember.setText("Ingat NIK otomatis di perangkat ini");remember.setTextColor(ink);remember.setChecked(old!=null);body.addView(remember);
  gap();Button next=btn("Lanjut ke data kartu",true);body.addView(next);
  next.setOnClickListener(v->{String val=n.getText().toString().trim();if(!val.matches("\\d{16}")){toast("NIK harus tepat 16 digit.");return;}
   if(remember.isChecked()){if(!saveNik(val)){toast("Gagal menyimpan NIK terenkripsi.");return;}}else deleteNik();
   cardScreen();
  });
  if(old!=null){gap();Button del=btn("Hapus NIK tersimpan",false);body.addView(del);del.setOnClickListener(v->{deleteNik();n.setText("");remember.setChecked(false);toast("NIK tersimpan dihapus.");});}
  gap();note("NIK yang diingat dienkripsi lokal menggunakan Android Keystore. Tidak dikirim ke server XLSMART. Jangan simpan NIK tanpa persetujuan pemilik identitas.");
 }
 private void cardScreen(){
  shell("Data kartu",brand+" • Scan barcode atau ketik manual.");
  label("Nomor HP");phone=field("Masukkan nomor HP",android.text.InputType.TYPE_CLASS_PHONE);body.addView(phone);
  Button sp=btn("Scan barcode kartu",false);body.addView(sp);sp.setOnClickListener(v->scan(phone,false));gap();
  label("4 digit terakhir CCID / ICCID");ccid=field("Masukkan 4 digit terakhir",android.text.InputType.TYPE_CLASS_NUMBER);body.addView(ccid);
  Button sc=btn("Scan barcode CCID",false);body.addView(sc);sc.setOnClickListener(v->scan(ccid,true));gap();
  Button open=btn("Buka portal registrasi "+brand,true);body.addView(open);open.setOnClickListener(v->openUrl(regUrl()));
  gap();Button add=btn("Simpan nomor ke daftar sesi",false);body.addView(add);add.setOnClickListener(v->{
   String p=phone.getText().toString().trim(),c=ccid.getText().toString().trim();
   if(p.length()<9){toast("Periksa nomor HP.");return;}if(!c.matches("\\d{4}")){toast("CCID harus 4 digit.");return;}
   if(!sessionNumbers.contains(p))sessionNumbers.add(p);numbersScreen();
  });
  gap();Button back=btn("Kembali",false);body.addView(back);back.setOnClickListener(v->home());
  gap();note("Hasil scan barcode dapat berupa ICCID, bukan nomor HP. Periksa hasilnya sebelum membuka portal. Kamera untuk selfie/face recognition akan diminta langsung oleh portal resmi bila diperlukan.");
 }
 private void scan(EditText target,boolean lastFour){
  GmsBarcodeScanning.getClient(this).startScan().addOnSuccessListener(code->{
   String raw=code.getRawValue();if(raw==null){toast("Barcode kosong.");return;}
   String digits=raw.replaceAll("\\D","");
   if(lastFour){if(digits.length()<4){toast("Kode kurang dari 4 digit.");return;}target.setText(digits.substring(digits.length()-4));}
   else {target.setText(raw);toast("Periksa hasil scan: barcode kartu biasanya berisi ICCID, bukan nomor HP.");}
  }).addOnCanceledListener(()->toast("Scan dibatalkan.")).addOnFailureListener(e->toast("Scanner gagal dibuka. Pastikan Google Play services tersedia."));
 }
 private void numbersScreen(){
  shell("Daftar nomor sesi", "Daftar sementara untuk membantu memilih nomor yang akan di-unreg.");
  if(sessionNumbers.isEmpty())body.addView(txt("Belum ada nomor.",13,Color.GRAY,false));
  for(String p:new ArrayList<>(sessionNumbers)){
   LinearLayout row=new LinearLayout(this);row.setPadding(10,8,8,8);row.setGravity( android.view.Gravity.CENTER_VERTICAL);row.setBackground(shape(Color.WHITE,14));
   row.addView(txt(p,15,ink,true),new LinearLayout.LayoutParams(0,-2,1));
   Button un=btn("Unreg",false);row.addView(un);un.setOnClickListener(v->{phoneForUnreg(p);});body.addView(row);gap();
  }
  Button back=btn("Tambah nomor",true);body.addView(back);back.setOnClickListener(v->cardScreen());
 }
 private void unregForm(){
  shell("Unreg nomor","Pilih nomor yang benar-benar milik pelanggan dan masih dapat mengirim SMS.");
  label("Nomor HP yang akan di-unreg");EditText p=field("Contoh 08xxxxxxxxxx",android.text.InputType.TYPE_CLASS_PHONE);body.addView(p);gap();
  Button send=btn("Buat SMS UNREG ke 4444",true);body.addView(send);send.setOnClickListener(v->{String num=p.getText().toString().trim();if(num.length()<9){toast("Masukkan nomor yang valid.");return;}phoneForUnreg(num);});
  gap();note("Format SMS resmi yang dipakai operator tertentu adalah UNREG#NomorHP#. Pastikan nomor yang dipilih adalah milik pelanggan. Pengiriman dan konfirmasi tetap dilakukan oleh pelanggan/operator.");
 }
 private void phoneForUnreg(String num){
  String msg="UNREG#"+num+"#";
  try{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:4444"));i.putExtra("sms_body",msg);startActivity(i);}
  catch(Exception e){toast("Aplikasi SMS tidak tersedia. Kirim manual: "+msg+" ke 4444");}
 }
 private String regUrl(){if("AXIS".equals(brand))return "https://registrasi.axis.co.id/";if("Smartfren".equals(brand))return "https://mysf.id/reg";return "https://registrasi.xl.co.id/";}
 private void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Browser tidak tersedia.");}}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

 // Encrypt remembered NIK with an AES-GCM key protected by Android Keystore.
 private SecretKey getKey() throws Exception{
  KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
  if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);
  KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
   .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
  return kg.generateKey();
 }
 private boolean saveNik(String s){
  try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getKey());byte[] iv=c.getIV();byte[] enc=c.doFinal(s.getBytes("UTF-8"));
   prefs.edit().putString("nik_iv",Base64.encodeToString(iv,Base64.NO_WRAP)).putString("nik_enc",Base64.encodeToString(enc,Base64.NO_WRAP)).apply();return true;
  }catch(Exception e){return false;}
 }
 private String loadNik(){
  try{String ivs=prefs.getString("nik_iv",null),es=prefs.getString("nik_enc",null);if(ivs==null||es==null)return null;
   Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getKey(),new GCMParameterSpec(128,Base64.decode(ivs,Base64.NO_WRAP)));
   return new String(c.doFinal(Base64.decode(es,Base64.NO_WRAP)),"UTF-8");
  }catch(Exception e){deleteNik();return null;}
 }
 private void deleteNik(){prefs.edit().remove("nik_iv").remove("nik_enc").apply();}
}
